package be.ixor.grails.extendedvalidation

class InstanceConstraintFactory {

    static InstanceConstraint create() {
        return new InstanceConstraint()
    }

}
